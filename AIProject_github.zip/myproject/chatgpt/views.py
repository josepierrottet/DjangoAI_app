from django.shortcuts import render
from django.views import View
from . import chat_module
from .chat_module import main  # Asegúrate de que esta importación sea correcta
from .chat_module import docx_to_text
from .chat_module import text_to_docx
import os
from django.http import JsonResponse
respuesta1=""
class ChatGPTView(View):
    template_name = "ai_app/chat2.html"
    

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        uploaded_file = request.FILES['document']
        search_query = request.POST.get('query', '')  # Obtén la consulta de búsqueda de la solicitud POST
        if uploaded_file:
            temp_file_path = os.path.join(r'\\192.168.1.202\Temporal', uploaded_file.name)
            with open(temp_file_path, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            txtsinformato=docx_to_text(temp_file_path)
            docxsinformato=text_to_docx(txtsinformato)
            response = main(search_query=search_query, camino=docxsinformato)  # Pasa la consulta de búsqueda a la función main
            global respuesta1
            respuesta1=response
            return render(request, self.template_name, {'generated_text': response})  # Se corrigió esta línea

        return render(request, self.template_name)



class NewRequestView(View):
    template_name = "ai_app/contexto.html"

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        requerimiento = request.POST.get('query_modal', '')  # Obtén la consulta de búsqueda de la solicitud POST
        contextualized_response = chat_module.contextualizador(requerimiento, respuesta1)
        if requerimiento:
            print(requerimiento)
        else:
            print("no ha requerimiento")
        
        # En lugar de renderizar una nueva página, devuelve una respuesta JSON con el texto contextualizado
        return JsonResponse({'contextualized_text': contextualized_response})


