from django.urls import path
from . import views

urlpatterns=[
    path("chat2/", views.ChatGPTView.as_view(), name="chat2"),
    path("chat3/", views.NewRequestView.as_view(), name="chat3"),  # Nueva URL para NewRequestView
]
