import openai
import os
import pyautogui
import time
import requests
from googleapiclient.discovery import build
import requests
from bs4 import BeautifulSoup
import datetime
import urllib.parse
from pathlib import Path
from urllib.parse import urljoin
from docx import Document
from tkinter import filedialog
from tkinter import Tk
import tempfile
from docx import Document

openai.api_key = "my_api_key"
google_api_key = "my_api_key"
google_cse_id = "my_api_key"

nombrecito=""






def leer_archivo_word_en_chunks(path, max_chars=1250):
    doc = Document(path)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    full_text = ' '.join(full_text)
    
    start = 0
    while start < len(full_text):
        end = start + max_chars
        if end < len(full_text):
            # Extender el chunk hasta el final de la oración más cercana
            while end < len(full_text) and full_text[end] != '.':
                end += 1
        chunk = full_text[start:end+1]  # Se suma 1 para incluir el punto final
        yield chunk
        start = end + 1  # Se suma 1 para no incluir el punto en el siguiente chunk




def chatgpt_response(messages):
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        temperature=0.7,
        top_p=0.1,

        frequency_penalty=1,
        messages=messages
    )
    return completion.choices[0].message["content"]

def contextualizador(requerimiento,contexto):
    
    
    
    # Obtener la fecha y hora actual
    fecha_hora_actual = datetime.datetime.now()

    # Convertir la fecha y hora a una cadena
    fecha_hora_string = fecha_hora_actual.strftime("%Y-%m-%d %H:%M:%S")
    



    messages = [
    {"role": "system", "content":"Realiza todo lo que te pido de manera eficiente"},
    {"role": "system", "content":"Tu trabajo es responder el requerimiento de los usuarios cuando te pidan que hagas algo relacionado con a respuesta que dió el modelo de AI"},
    {"role": "system", "content":"La fecha y hora actual es: " + fecha_hora_string},
    {"role": "user", "content":"Necesito que actues como un experto en {}".format(nombrecito)},
    {"role": "user", "content":"Te voy a dar una respuesta que me dió un modelo de AI acerca de un documento"},
    {"role": "user", "content":"La respuesta es {}".format(contexto)},
    {"role": "user", "content":"Tu trabajo es responder el requerimiento de los usuarios cuando te pidan que hagas algo relacionado con a respuesta que dió el modelo de AI"},
    {"role": "user", "content":"El requerimiento del usuario es el siguiente"},
    {"role": "user", "content":requerimiento},
    ]

    respuesta=chatgpt_response(messages)

    return respuesta

def docx_to_text(file_path):
    doc = Document(file_path)
    full_text = []

    # Extraer texto de los párrafos
    for para in doc.paragraphs:
        full_text.append(para.text)

    # Extraer texto de las tablas
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                full_text.append(cell.text)

    # Crea un archivo temporal y escribe el texto en él
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    with open(temp_file.name, 'w', encoding='latin-1', errors='ignore') as file:
        file.write('\n'.join(full_text))

    return temp_file.name



def text_to_docx(filepath):
    # Crear nuevo Documento
    doc = Document()

    # Leer el archivo de texto
    with open(filepath, 'r') as file:
        text = file.read()
        
    # Añadir el texto al documento
    doc.add_paragraph(text)

    # Crear un archivo temporal para guardar el docx
    temp_file = tempfile.NamedTemporaryFile(suffix=".docx", delete=False)
    
    temp_path = temp_file.name
    print(temp_path)

    # Guardar el documento en el archivo temporal
    doc.save(temp_path)

    return temp_path




def get_filename(filepath):
    base_name = os.path.basename(filepath)  # Obtiene el nombre del archivo con la extensión
    file_name, _ = os.path.splitext(base_name)  # Separa el nombre del archivo y la extensión
    return file_name

def main(search_query, camino):
    request_count = 0
    url_pci=camino
    
    found_answer = False
    # Obtener la fecha y hora actual
    fecha_hora_actual = datetime.datetime.now()

    # Convertir la fecha y hora a una cadena
    fecha_hora_string = fecha_hora_actual.strftime("%Y-%m-%d %H:%M:%S")
    

    if search_query.lower() == 'salir':
        return "Consulta inválida"


    messages = [
    {"role": "system", "content":"Realiza todo lo que te pido de manera eficiente"},
    {"role": "system", "content":"La fecha y hora actual es: " + fecha_hora_string},
    {"role": "system", "content":"Tu rol es ayudarme a encontrar respuestas iterando a traves de varios textos , por favor escucha muy bien mis instrucciones"},
    {"role": "system", "content":"Si no encuentras una respuesta, siempre responde <Respuesta no encontrada>"},
    {"role": "user", "content": "Estamos en el año 2023, por lo tanto si se te pregunta algo relacionado a la actualidad, ten en cuenta eso"},
    {"role": "user", "content": "Te voy a dar texto que es el resultado de chunks de un texto más grande"},
    {"role": "user", "content": "Debido al límite de tokens este texto tendrá un máximo de 1300 caracteres"},
    {"role": "user", "content": "Si no encuentras una respuesta exacta en estos 1300 caracteres entonces siempre responde <Respuesta no encontrada> para que podamos iterar en los siguientes 1300 caracteres"},
    {"role": "user", "content": "La pregunta o requerimiento que debes responder es la siguiente"},
    {"role": "user", "content": search_query},
    {"role": "user", "content": "Necesitas encontrar la respuesta a esa pregunta en los textos que te voy a ir proporcionando"},
    {"role": "user", "content": "Recuerda que si no encuentras la respuesta, siempre debes responder <Respuesta no encontrada> y ni un solo caracter extra"},
    {"role": "user", "content": "En caso de que encuentres DENTRO DE LOS TEXTOS una respuesta escribela de modo que responda la pregunta original de mejor manera y haz tu mejor esfuerzo por complementar esa respuesta con tus propios conocimientos si es posible"}
]

    generador = leer_archivo_word_en_chunks(url_pci)
        

    for chunk in generador:
            
        messages_chunk = messages.copy()
        messages_chunk.append({"role": "user", "content": chunk})
        generated_text = chatgpt_response(messages_chunk)
            
        request_count += 1
        if request_count % 3 == 0:
            print("Esperando 1 minuto")
            time.sleep(61)

        if ("spuesta no encontrada" not in generated_text.strip()) and ("proporcionarme otro" not in generated_text.strip()) and ("no está presente" not in generated_text.strip()) and ("encuentra la respuesta" not in generated_text.strip()) and ("o siento" not in generated_text.strip() and ("o he encontrado una respuesta" not in generated_text.strip()) and ("requerimiento en este texto" not in generated_text.strip()) and ("No se ha encontrado") not in generated_text.strip() and ("o se especifica") not in generated_text.strip()):
            found_answer = True
            with open("Respuesta_de_la_ultima_preguntaSL.txt", "w", encoding="utf-8") as archivo:
                archivo.write(generated_text)
            
            global nombrecito
            
            nombrecito=get_filename(url_pci)
            
            
            return generated_text

        if found_answer:
            break

    return "<Respuesta no encontrada aqui>"



