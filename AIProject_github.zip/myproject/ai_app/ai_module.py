import openai
import os
import pyautogui
import time
import requests
from googleapiclient.discovery import build
import requests
from bs4 import BeautifulSoup
import datetime

openai.api_key = "my_api_key"
google_api_key = "my_api_key"
google_cse_id = "my_api_key"
#prompt = "Quien gano el mundial del 2022"

def google_search(query):
    
    
    
    
    service = build("customsearch", "v1", developerKey=google_api_key)
    results = service.cse().list(q=query, cx=google_cse_id, num=5,gl="ec").execute()
    return results["items"]


def process_search_results(results):
    top_results = results[:5]
    links = [result['link'] for result in top_results]
    
    
    print(links)
    return links

def scrape_page(url):
    try:
        response = requests.get(url, timeout=10)  # 10 segundos de tiempo de espera
    except requests.exceptions.RequestException as e:
        return ""

    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Agrega los elementos que deseas extraer en la lista 'elements_to_scrape'
    elements_to_scrape = ['p', 'ul', 'ol', 'li', 'div', 'article', 'section']
    text_elements = []

    # Itera a través de los elementos en 'elements_to_scrape' y extrae su contenido de texto
    for element in elements_to_scrape:
        text_elements += soup.find_all(element)

    # Combina el texto de todos los elementos extraídos en una sola cadena
    text = ' '.join([text_element.text for text_element in text_elements])

    # Elimina todos los espacios en blanco
    text = text.replace(" ", "")

    with open("scraped_completo.txt", "w", encoding="utf-8") as archivo:
            archivo.write(text)
    return text




def reformulador(requerimiento):
    
    messages = [
    {"role": "system", "content":"Eres un asistente para formular preguntas a google"},
    {"role": "system", "content":"No debes nunca hacerme más preguntas a mí, ya que tu primera respuesta será envíada al buscador"},
    {"role": "system", "content":"No me pidas confirmaciones ni nada parecido, solo hazlo"},
    {"role": "user", "content":"No debes nunca hacerme más preguntas a mí yo solo te voy a dar un requerimiento, ya que tu primera respuesta será envíada al buscador"},
    {"role": "user", "content":"Te voy a dar un requerimiento, este puede ser en forma de pregunta o de un objetivo"},
    {"role": "user", "content":"Tu misión es reformular el requerimiento lo mejor posible para mandarselo al buscador de google"},
    {"role": "user", "content":"No me pidas confirmaciones ni nada parecido, solo hazlo"},
    {"role": "system", "content":"Tu única respuesta debe ser la formularión de requermientos a un buscador, dado un objetivo"},
    {"role": "user", "content":"Cuando digo reformular me refiero, a que uses operadores de búsqueda si es necesario"},
    {"role": "user", "content":"Por ejemplo, dame 3 articulos cientificos del 2021"},
    {"role": "assistant", "content":"'Artículo científico' 2021"},
    {"role": "user", "content":"Otro ejemplo, Dame ejemplos que sean lo más grande del mundo"},
    {"role": "assistant", "content":"'La mayor * del mundo'"},
    {"role": "user", "content":"Otro ejemplo, En que calle se encuentra Tac n Roll?"},
    {"role": "assistant", "content":"Calle Tac n Roll"},
    {"role": "user", "content":"Otro ejemplo, Que lugares turísticos puedo visitar en Quito?, y que comidas hay ahí?"},
    {"role": "assistant", "content":"'Lugares Turísticos Quito y sus comidas'"},
    {"role": "user", "content":"Entendiste?"},
    {"role": "assistant", "content":"Sí, entiendo perfecto, solo debo reformular el objetivo o requerimiento que me diste para que a búsqueda en google sea efectiva"},
    {"role": "user", "content":"El requerimiento es:"},
    {"role": "user", "content":requerimiento},
    
]
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        temperature=0.7,
        top_p=0.1,

        frequency_penalty=1,
        messages=messages
    )
    print(completion.choices[0].message["content"])
    print("esperando")
    time.sleep(61)
    
    return completion.choices[0].message["content"]

def chatgpt_response(messages):
    
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        temperature=0.7,
        top_p=0.1,

        frequency_penalty=1,
        messages=messages
    )
    return completion.choices[0].message["content"]

def split_text(text, max_length=1200):
    chunks = []
    current_index = 0

    while current_index < len(text):
        end_index = current_index + max_length

        if end_index < len(text):
            # Buscar el último punto en el rango actual
            last_period_index = text.rfind(">", current_index, end_index)
            
            # Si se encuentra un punto, actualizar el índice final para que termine después del punto
            if last_period_index != -1:
                end_index = last_period_index + 1

        # Agregar el fragmento de texto a la lista de chunks
        chunks.append(text[current_index:end_index])
        current_index = end_index
        a="".join(chunks)
        with open("chunks.txt", "w", encoding="utf-8") as archivo:
            archivo.write(a)
        

    return chunks

def ai_chat(search_query):
    if not search_query.strip():
        return "Por favor, ingrese una pregunta."
    
    request_count = 0

    if search_query.lower() == 'salir':
        return "Consulta inválida"
        
    # Obtener la fecha y hora actual
    fecha_hora_actual = datetime.datetime.now()

    # Convertir la fecha y hora a una cadena
    fecha_hora_string = fecha_hora_actual.strftime("%Y-%m-%d %H:%M:%S")

    search_results = google_search(search_query)
    top_links = process_search_results(search_results)

    scraped_texts = []
    links_lista=[]
    for link in top_links:
        links_lista.append(link)
        scraped_text = scrape_page(link)
        scraped_texts.append(scraped_text)

    messages = [
    {"role": "system", "content":"Piensa bien en el requerimiento antes de responder"},
    {"role": "system", "content": "Los textos que te voy a proporcionar están sin ningún espacio en blanco, por lo que cuando respondas debes hacerlo legible para las personas"},
    {"role": "system", "content": "Todas tus respuestas deben ser ortográficamente correctas y orientadas a responder el requerimiento"},
    {"role": "system", "content":"Cuando respondas, verifica muy bien la ortografía y la sintaxis de tu respuesta"},
    {"role": "system", "content":"Piensa en que manera puedes dar tu respuesta, de modo que sea lo más util posible para mí."},
    {"role": "system", "content":"La fecha y hora actual es: " + fecha_hora_string},
    {"role": "system", "content":"Tu rol es ayudarme a encontrar respuestas iterando a traves de varios textos, por favor escucha muy bien mis instrucciones"},
    {"role": "system", "content":"Si no encuentras una respuesta, siempre responde <Respuesta no encontrada>"},
    {"role": "user", "content": "Estamos en el año 2023, por lo tanto si se te pregunta algo relacionado a la actualidad, ten en cuenta eso"},
    {"role": "user", "content": "Te voy a dar texto que es el resultado de web scrapping para que me ayudes a responder un requerimiento u objetivo que le hice a un buscador"},
    {"role": "user", "content": "Debido al límite de tokens este texto tendrá un máximo de 1300 caracteres"},
    {"role": "user", "content": "Si no encuentras una respuesta en estos 1300 caracteres entonces siempre responde <Respuesta no encontrada> para que podamos iterar en los siguientes 1300 caracteres"},
    {"role": "user", "content": "El requerimiento u objetivo que le hice fue el siguiente"},
    {"role": "user", "content": search_query},
    {"role": "user", "content": "Los textos están sin ningún espacio en blanco, por lo que cuando respondas debes hacerlo legible para las personas"},
    {"role": "user", "content": "Todas tus respuestas deben ser ortográficamente correctas y orientadas a responder el requerimiento"},
    {"role": "user", "content": "Este es un ejemplo, 'Quien fundó Logikard?'"},
    {"role": "assistant", "content": "El fundador de Logikard es Frank Nankervis, quien la fundó el 16 de julio de 1996.'"},
    {"role": "user", "content": "Este es otro ejemplo, 'Que es el caso gran padrino?'"},
    {"role": "assistant", "content": "El caso Gran Padrino es una investigación preprocesal sobre casos de corrupción en Ecuador. La investigación es llevada a cabo por la Fiscalía General del Estado en contra de varios funcionarios públicos dentro de empresas públicas. La investigación surgió a raíz de un reportaje periodístico realizado por el medio de comunicación digital La Posta, en donde se detallaba una red de corrupción en la que estarían involucrados Danilo Carrera Drouet y Rubén Cherres Faggioni. Los delitos investigados son delincuencia organizada, cohecho y concusión.'"},
    {"role": "user", "content": "Entendiste como debes responder?'"},
    {"role": "assistant", "content": "Sí, entiendo perfectamente. A pesar de que los textos que me proporcionaste no tienen espacios y son dificiles de leer, cuando yo responda tengo que hacerlo de manera clara y legible'"},
    {"role": "user", "content": "Necesitas encontrar la respuesta exacta a este requerimiento u objetivo ({}) en los textos, recuerda que si no encuentras una respuesta debes responder <Respuesta no encontrada> y ni un solo caracter extra".format(search_query)},
    {"role": "user", "content": "En caso de que encuentres una respuesta escribela de modo que responda el requerimiento proporcionado de mejor manera y haz tu mejor esfuerzo por complementar esa respuesta con tus propios conocimientos si es necesario"},
    
]

    for scraped_text in scraped_texts:
        text_chunks = split_text(scraped_text)
        found_answer = False

        for chunk in text_chunks:
            messages.append({"role": "user", "content": chunk})
            generated_text = chatgpt_response(messages)

            request_count += 1
            if request_count % 3 == 0:
                print("Esperando 1 minuto")
                time.sleep(61)

            if ("spuesta no encontrada" not in generated_text.strip()) and ("proporcionarme otro" not in generated_text.strip()) and ("no está presente" not in generated_text.strip()) and ("encuentra la respuesta" not in generated_text.strip()) and ("o siento" not in generated_text.strip() and ("o he encon" not in generated_text.strip()) and ("requerimiento en este texto" not in generated_text.strip()) and ("No se ha encontrado") not in generated_text.strip() and ("o se especifica") not in generated_text.strip()):
                found_answer = True
                with open("Respuesta_de_la_ultima_preguntaSL.txt", "w", encoding="utf-8") as archivo:
                    archivo.write(generated_text)
                return generated_text, links_lista

        if found_answer:
            break

    return "<Respuesta no encontrada en el texto, pero quizá si buscas en una de las fuentes que te proporcioné>",links_lista



