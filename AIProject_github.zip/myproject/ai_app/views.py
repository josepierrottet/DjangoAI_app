from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse
from .ai_module import ai_chat,reformulador



def chat(request):
    query = request.GET.get('query', '')
    if not query:
        return render(request, 'ai_app/chat.html')
    reformulacion=reformulador(query)
    response,links = ai_chat(reformulacion)
    return JsonResponse({'response': response, 'links':links})



def home(request):
    return render(request, 'ai_app/home.html')

