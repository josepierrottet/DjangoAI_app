# views.py
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect
from django.contrib.auth.views import logout_then_login

class LoginView(View):
    
    def get(self, request, *args, **kwargs):
        return render(request, 'ai_app/login.html')
    
    
    def post(self, request, *args, **kwargs):
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')  # Redirige a la vista 'home'
        else:
            return HttpResponse('Error en el login', status=401)

# La vista de logout es una función, no una clase
def logout_view(request):
    return logout_then_login(request, 'home')
