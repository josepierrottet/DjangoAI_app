# myproject/myauth/backends.py
import requests
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

class MyCustomBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        User = get_user_model()

        # Realiza la solicitud a la API externa
        response = requests.post('http://192.168.12.22/api/Account/Login', json={
            'Email': username,
            'Password': password,
            'RememberMe': False,
        })

        # Verifica que la respuesta sea exitosa
        if response.status_code == 200:
            data = response.json()

            # Intenta obtener el usuario de la base de datos
            user, created = User.objects.get_or_create(username=data['userName'],
                                                       defaults={'email': data['userEmail'],
                                                                 'first_name': data['nombreApellido']})

            return user

        # Si la respuesta no es exitosa, devuelve None
        return None
