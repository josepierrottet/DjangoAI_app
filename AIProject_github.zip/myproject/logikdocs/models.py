# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Aspnetroles(models.Model):
    id = models.CharField(db_column='Id', primary_key=True, max_length=128)  # Field name made lowercase.
    name = models.CharField(db_column='Name', unique=True, max_length=256)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'AspNetRoles'


class Aspnetuserclaims(models.Model):
    id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    userid = models.ForeignKey('Aspnetusers', models.DO_NOTHING, db_column='UserId')  # Field name made lowercase.
    claimtype = models.TextField(db_column='ClaimType', blank=True, null=True)  # Field name made lowercase.
    claimvalue = models.TextField(db_column='ClaimValue', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'AspNetUserClaims'


class Aspnetuserlogins(models.Model):
    loginprovider = models.CharField(db_column='LoginProvider', primary_key=True, max_length=128)  # Field name made lowercase.
    providerkey = models.CharField(db_column='ProviderKey', max_length=128)  # Field name made lowercase.
    userid = models.ForeignKey('Aspnetusers', models.DO_NOTHING, db_column='UserId')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'AspNetUserLogins'
        unique_together = (('loginprovider', 'providerkey', 'userid'),)


class Aspnetuserroles(models.Model):
    userid = models.ForeignKey('Aspnetusers', models.DO_NOTHING, db_column='UserId', primary_key=True)  # Field name made lowercase.
    roleid = models.ForeignKey(Aspnetroles, models.DO_NOTHING, db_column='RoleId')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'AspNetUserRoles'
        unique_together = (('userid', 'roleid'),)


class Aspnetusers(models.Model):
    id = models.CharField(db_column='Id', primary_key=True, max_length=128)  # Field name made lowercase.
    nameidentifier = models.TextField(db_column='NameIdentifier', blank=True, null=True)  # Field name made lowercase.
    email = models.CharField(db_column='Email', max_length=256, blank=True, null=True)  # Field name made lowercase.
    emailconfirmed = models.BooleanField(db_column='EmailConfirmed')  # Field name made lowercase.
    passwordhash = models.TextField(db_column='PasswordHash', blank=True, null=True)  # Field name made lowercase.
    securitystamp = models.TextField(db_column='SecurityStamp', blank=True, null=True)  # Field name made lowercase.
    phonenumber = models.TextField(db_column='PhoneNumber', blank=True, null=True)  # Field name made lowercase.
    phonenumberconfirmed = models.BooleanField(db_column='PhoneNumberConfirmed')  # Field name made lowercase.
    twofactorenabled = models.BooleanField(db_column='TwoFactorEnabled')  # Field name made lowercase.
    lockoutenddateutc = models.DateTimeField(db_column='LockoutEndDateUtc', blank=True, null=True)  # Field name made lowercase.
    lockoutenabled = models.BooleanField(db_column='LockoutEnabled')  # Field name made lowercase.
    accessfailedcount = models.IntegerField(db_column='AccessFailedCount')  # Field name made lowercase.
    username = models.CharField(db_column='UserName', unique=True, max_length=256)  # Field name made lowercase.
    cargoid = models.BigIntegerField(db_column='CargoId')  # Field name made lowercase.
    per_id = models.BigIntegerField(db_column='Per_Id')  # Field name made lowercase.
    idcargo = models.ForeignKey('Cargo', models.DO_NOTHING, db_column='idCargo', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'AspNetUsers'


class Cargo(models.Model):
    departid = models.ForeignKey('Departamento', models.DO_NOTHING, db_column='DEPARTID')  # Field name made lowercase.
    cargoid = models.BigAutoField(db_column='CARGOID', primary_key=True)  # Field name made lowercase.
    cargonombre = models.CharField(db_column='CARGONOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    cargocodigo = models.CharField(db_column='CARGOCODIGO', max_length=10, blank=True, null=True)  # Field name made lowercase.
    cargoestado = models.IntegerField(db_column='CARGOESTADO', blank=True, null=True)  # Field name made lowercase.
    cargoaudusuariocrea = models.CharField(db_column='CARGOAUDUSUARIOCREA', max_length=350, blank=True, null=True)  # Field name made lowercase.
    cargoaudfechacrea = models.DateTimeField(db_column='CARGOAUDFECHACREA', blank=True, null=True)  # Field name made lowercase.
    cargoaudusuariomodifica = models.CharField(db_column='CARGOAUDUSUARIOMODIFICA', max_length=350, blank=True, null=True)  # Field name made lowercase.
    cargoaudfechamodifica = models.DateTimeField(db_column='CARGOAUDFECHAMODIFICA', blank=True, null=True)  # Field name made lowercase.
    cargo_jefe = models.ForeignKey('self', models.DO_NOTHING, db_column='CARGO_JEFE', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CARGO'


class CargoDocumentos(models.Model):
    idcargodocumentos = models.BigAutoField(db_column='IDCARGODOCUMENTOS', primary_key=True)  # Field name made lowercase.
    documentoid_ref = models.ForeignKey('Documento', models.DO_NOTHING, db_column='DOCUMENTOID_REF', blank=True, null=True, related_name='cargos_documento_ref')  # Field name made lowercase.
    documentoid = models.ForeignKey('Documento', models.DO_NOTHING, db_column='DOCUMENTOID', blank=True, null=True, related_name='cargos_documento')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CARGO_DOCUMENTOS'



class CargoProcesos(models.Model):
    procesoid = models.ForeignKey('Proceso', models.DO_NOTHING, db_column='PROCESOID')  # Field name made lowercase.
    cargoid = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='CARGOID')  # Field name made lowercase.
    idcargoproceso = models.BigAutoField(db_column='IDCARGOPROCESO', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CARGO_PROCESOS'


class CargoSubproceso(models.Model):
    idcargoproceso = models.BigAutoField(db_column='IDCARGOPROCESO', primary_key=True)  # Field name made lowercase.
    cargoid = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='CARGOID', blank=True, null=True)  # Field name made lowercase.
    subprocid = models.ForeignKey('Subproceso', models.DO_NOTHING, db_column='SUBPROCID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'CARGO_SUBPROCESO'


class Departamento(models.Model):
    departid = models.BigAutoField(db_column='DEPARTID', primary_key=True)  # Field name made lowercase.
    departnombre = models.CharField(db_column='DEPARTNOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    departcodigo = models.CharField(db_column='DEPARTCODIGO', max_length=10, blank=True, null=True)  # Field name made lowercase.
    departestado = models.IntegerField(db_column='DEPARTESTADO', blank=True, null=True)  # Field name made lowercase.
    departusuariocrea = models.CharField(db_column='DEPARTUSUARIOCREA', max_length=350, blank=True, null=True)  # Field name made lowercase.
    departfechacrea = models.DateTimeField(db_column='DEPARTFECHACREA', blank=True, null=True)  # Field name made lowercase.
    departusuariomodifica = models.CharField(db_column='DEPARTUSUARIOMODIFICA', max_length=350, blank=True, null=True)  # Field name made lowercase.
    departfechamodifica = models.DateTimeField(db_column='DEPARTFECHAMODIFICA', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DEPARTAMENTO'


class Distribuciondocumentos(models.Model):
    distridocsid = models.BigAutoField(db_column='DISTRIDOCSID', primary_key=True)  # Field name made lowercase.
    distridocsnombre = models.CharField(db_column='DISTRIDOCSNOMBRE', max_length=500, blank=True, null=True)  # Field name made lowercase.
    distridocsdetalle = models.CharField(db_column='DISTRIDOCSDETALLE', max_length=500, blank=True, null=True)  # Field name made lowercase.
    distridocsestado = models.IntegerField(db_column='DISTRIDOCSESTADO', blank=True, null=True)  # Field name made lowercase.
    subprocesoid = models.ForeignKey('Subproceso', models.DO_NOTHING, db_column='SUBPROCESOID', blank=True, null=True)  # Field name made lowercase.
    numdistri = models.CharField(db_column='NUMDISTRI', max_length=500, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DISTRIBUCIONDOCUMENTOS'


class Documento(models.Model):
    idflujoaprobacion = models.BigIntegerField(db_column='IDFLUJOAPROBACION', blank=True, null=True)  # Field name made lowercase.
    tdocid = models.ForeignKey('Tipodocumento', models.DO_NOTHING, db_column='TDOCID')  # Field name made lowercase.
    documentoid = models.BigAutoField(db_column='DOCUMENTOID', primary_key=True)  # Field name made lowercase.
    idtipestdoc = models.ForeignKey('Tipoestadodocumento', models.DO_NOTHING, db_column='IDTIPESTDOC')  # Field name made lowercase.
    documentocodigo = models.CharField(db_column='DOCUMENTOCODIGO', max_length=30, blank=True, null=True)  # Field name made lowercase.
    documentoversion = models.IntegerField(db_column='DOCUMENTOVERSION', blank=True, null=True)  # Field name made lowercase.
    documentonombre = models.CharField(db_column='DOCUMENTONOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    documentodetalleid = models.TextField(db_column='DOCUMENTODETALLEID', blank=True, null=True)  # Field name made lowercase.
    documentousucrea = models.CharField(db_column='DOCUMENTOUSUCREA', max_length=128, blank=True, null=True)  # Field name made lowercase.
    documentofeccrea = models.DateTimeField(db_column='DOCUMENTOFECCREA', blank=True, null=True)  # Field name made lowercase.
    documentofecmod = models.DateTimeField(db_column='DOCUMENTOFECMOD', blank=True, null=True)  # Field name made lowercase.
    documentousumod = models.CharField(db_column='DOCUMENTOUSUMOD', max_length=128, blank=True, null=True)  # Field name made lowercase.
    documentoestado = models.IntegerField(db_column='DOCUMENTOESTADO', blank=True, null=True)  # Field name made lowercase.
    documentoobservacion = models.CharField(db_column='DOCUMENTOOBSERVACION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    document_padre = models.BigIntegerField(db_column='DOCUMENT_PADRE', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DOCUMENTO'


class DocumentoReferencia(models.Model):
    doc_ref_id = models.BigAutoField(db_column='DOC_REF_ID', primary_key=True)  # Field name made lowercase.
    referencia = models.ForeignKey('Referencia', models.DO_NOTHING, db_column='REFERENCIA_ID', blank=True, null=True)  # Field name made lowercase.
    documento = models.ForeignKey(Documento, models.DO_NOTHING, db_column='DOCUMENTO_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DOCUMENTO_REFERENCIA'


class DocumentoResponsabilidad(models.Model):
    id_dco_res = models.BigAutoField(db_column='ID_DCO_RES', primary_key=True)  # Field name made lowercase.
    doc = models.ForeignKey(Documento, models.DO_NOTHING, db_column='DOC_ID', blank=True, null=True)  # Field name made lowercase.
    cargo = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='CARGO_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DOCUMENTO_RESPONSABILIDAD'


class DocumentSubproc(models.Model):
    distridocsid = models.ForeignKey(Distribuciondocumentos, models.DO_NOTHING, db_column='DISTRIDOCSID')  # Field name made lowercase.
    documentoid = models.ForeignKey(Documento, models.DO_NOTHING, db_column='DOCUMENTOID')  # Field name made lowercase.
    id_doc_subproc = models.BigAutoField(db_column='ID_DOC_SUBPROC', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'DOCUMENT_SUBPROC'


class Flujoaprobacion(models.Model):
    idflujoaprobacion = models.BigAutoField(db_column='IDFLUJOAPROBACION', primary_key=True)  # Field name made lowercase.
    num_doc_flujoaprobacion = models.ForeignKey(Documento, models.DO_NOTHING, db_column='NUM_DOC_FLUJOAPROBACION', blank=True, null=True)  # Field name made lowercase.
    fase_anterior_flujoaprobacion = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='FASE_ANTERIOR_FLUJOAPROBACION', blank=True, null=True,related_name='flujos_fase_actual')  # Field name made lowercase.
    fase_actual_flujoaprobacion = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='FASE_ACTUAL_FLUJOAPROBACION', blank=True, null=True, related_name='flujos_fase_anterior')  # Field name made lowercase.
    fecha_flujoaprobacion = models.DateTimeField(db_column='FECHA_FLUJOAPROBACION', blank=True, null=True)  # Field name made lowercase.
    estado_flujoaprobacion = models.IntegerField(db_column='ESTADO_FLUJOAPROBACION', blank=True, null=True)  # Field name made lowercase.
    usuario_flujoaprobacion = models.CharField(db_column='USUARIO_FLUJOAPROBACION', max_length=128, blank=True, null=True)  # Field name made lowercase.
    tip_acc = models.ForeignKey('TipoAccionDocumento', models.DO_NOTHING, db_column='TIP_ACC_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'FLUJOAPROBACION'


class FlujoApruebaDocumento(models.Model):
    idflujoapro = models.BigAutoField(db_column='IDFLUJOAPRO', primary_key=True)  # Field name made lowercase.
    documentoid = models.BigIntegerField(db_column='DOCUMENTOID', blank=True, null=True)  # Field name made lowercase.
    fase = models.BigIntegerField(db_column='FASE', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'FLUJO_APRUEBA_DOCUMENTO'


class Historicoaprobacion(models.Model):
    hisaprobid = models.BigAutoField(db_column='HISAPROBID', primary_key=True)  # Field name made lowercase.
    hisaprobdetalle = models.CharField(db_column='HISAPROBDETALLE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    hisaprobusuariocrea = models.BigIntegerField(db_column='HISAPROBUSUARIOCREA', blank=True, null=True)  # Field name made lowercase.
    hisaprobfecha = models.DateTimeField(db_column='HISAPROBFECHA', blank=True, null=True)  # Field name made lowercase.
    hisaprobtipo = models.IntegerField(db_column='HISAPROBTIPO', blank=True, null=True)  # Field name made lowercase.
    hisaprobestado = models.IntegerField(db_column='HISAPROBESTADO', blank=True, null=True)  # Field name made lowercase.
    documentoid = models.ForeignKey(Documento, models.DO_NOTHING, db_column='DOCUMENTOID', blank=True, null=True)  # Field name made lowercase.
    tipaprob = models.ForeignKey('Tipoaprobacion', models.DO_NOTHING, db_column='TIPAPROB', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'HISTORICOAPROBACION'


class Historicodocumento(models.Model):
    hisdocid = models.BigAutoField(db_column='HISDOCID', primary_key=True)  # Field name made lowercase.
    hisdocdescripcion = models.CharField(db_column='HISDOCDESCRIPCION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    hisdocfecha = models.DateTimeField(db_column='HISDOCFECHA', blank=True, null=True)  # Field name made lowercase.
    histdocseccion = models.CharField(db_column='HISTDOCSECCION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    histdocusuariocrea = models.CharField(db_column='HISTDOCUSUARIOCREA', max_length=128, blank=True, null=True)  # Field name made lowercase.
    histdocestado = models.IntegerField(db_column='HISTDOCESTADO', blank=True, null=True)  # Field name made lowercase.
    documentoid = models.ForeignKey(Documento, models.DO_NOTHING, db_column='DOCUMENTOID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'HISTORICODOCUMENTO'


class Perfil(models.Model):
    per_id = models.BigAutoField(db_column='PER_ID', primary_key=True)  # Field name made lowercase.
    per_nombre = models.CharField(db_column='PER_NOMBRE', max_length=250, blank=True, null=True)  # Field name made lowercase.
    per_estado = models.IntegerField(db_column='PER_ESTADO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PERFIL'


class Proceso(models.Model):
    procesoid = models.BigAutoField(db_column='PROCESOID', primary_key=True)  # Field name made lowercase.
    procesonombre = models.CharField(db_column='PROCESONOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    procesodetalle = models.CharField(db_column='PROCESODETALLE', max_length=500, blank=True, null=True)  # Field name made lowercase.
    procesoestado = models.IntegerField(db_column='PROCESOESTADO', blank=True, null=True)  # Field name made lowercase.
    id_tipo_proceso = models.ForeignKey('TipoProceso', models.DO_NOTHING, db_column='ID_TIPO_PROCESO', blank=True, null=True)  # Field name made lowercase.
    num_proceso = models.CharField(db_column='NUM_PROCESO', max_length=50)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'PROCESO'


class Referencia(models.Model):
    referenciaid = models.BigAutoField(db_column='REFERENCIAID', primary_key=True)  # Field name made lowercase.
    tipreferenciaid = models.ForeignKey('Tiporeferencia', models.DO_NOTHING, db_column='TIPREFERENCIAID', blank=True, null=True)  # Field name made lowercase.
    referenciadescripcion = models.TextField(db_column='REFERENCIADESCRIPCION', blank=True, null=True)  # Field name made lowercase.
    referenciaobservacion = models.CharField(db_column='REFERENCIAOBSERVACION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    referenciaestado = models.IntegerField(db_column='REFERENCIAESTADO', blank=True, null=True)  # Field name made lowercase.
    referencianombre = models.CharField(db_column='REFERENCIANOMBRE', max_length=500, blank=True, null=True)  # Field name made lowercase.
    referenciatipo = models.CharField(db_column='REFERENCIATIPO', max_length=150, blank=True, null=True)  # Field name made lowercase.
    idubicacion = models.ForeignKey('UbicacionArchivo', models.DO_NOTHING, db_column='IDUBICACION', blank=True, null=True)  # Field name made lowercase.
    idtiempconserva = models.ForeignKey('TiempoConservacion', models.DO_NOTHING, db_column='IDTIEMPCONSERVA', blank=True, null=True)  # Field name made lowercase.
    referenciaversion = models.IntegerField(db_column='REFERENCIAVERSION', blank=True, null=True)  # Field name made lowercase.
    referenciausuariomod = models.CharField(db_column='REFERENCIAUSUARIOMOD', max_length=500, blank=True, null=True)  # Field name made lowercase.
    referenciafechamod = models.DateTimeField(db_column='REFERENCIAFECHAMOD', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'REFERENCIA'


class Responsabilidades(models.Model):
    idresponsabilidades = models.AutoField(db_column='IDRESPONSABILIDADES', primary_key=True)  # Field name made lowercase.
    documentoid = models.BigIntegerField(db_column='DOCUMENTOID')  # Field name made lowercase.
    cargoid = models.ForeignKey(Cargo, models.DO_NOTHING, db_column='CARGOID')  # Field name made lowercase.
    comenresponsabilidades = models.CharField(db_column='COMENRESPONSABILIDADES', max_length=2048, blank=True, null=True)  # Field name made lowercase.
    estresponsabilidades = models.IntegerField(db_column='ESTRESPONSABILIDADES', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'RESPONSABILIDADES'


class RolPerfil(models.Model):
    id_rol = models.ForeignKey(Aspnetroles, models.DO_NOTHING, db_column='ID_ROL')  # Field name made lowercase.
    id_perfil = models.ForeignKey(Perfil, models.DO_NOTHING, db_column='ID_PERFIL')  # Field name made lowercase.
    id_rol_perfil = models.BigAutoField(db_column='ID_ROL_PERFIL', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ROL_PERFIL'


class Subproceso(models.Model):
    procesoid = models.ForeignKey(Proceso, models.DO_NOTHING, db_column='PROCESOID')  # Field name made lowercase.
    subprocid = models.BigAutoField(db_column='SUBPROCID', primary_key=True)  # Field name made lowercase.
    subprocnombre = models.CharField(db_column='SUBPROCNOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    subprocdetalle = models.CharField(db_column='SUBPROCDETALLE', max_length=500, blank=True, null=True)  # Field name made lowercase.
    subprocestado = models.IntegerField(db_column='SUBPROCESTADO', blank=True, null=True)  # Field name made lowercase.
    numsubproc = models.CharField(db_column='NUMSUBPROC', max_length=500, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'SUBPROCESO'


class TiempoConservacion(models.Model):
    idtiempconserva = models.BigAutoField(db_column='IDTIEMPCONSERVA', primary_key=True)  # Field name made lowercase.
    detalletiempconserva = models.CharField(db_column='DETALLETIEMPCONSERVA', max_length=500, blank=True, null=True)  # Field name made lowercase.
    fecha_inicia = models.DateTimeField(db_column='FECHA_INICIA', blank=True, null=True)  # Field name made lowercase.
    fecha_termina = models.DateTimeField(db_column='FECHA_TERMINA', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIEMPO_CONSERVACION'


class Tipoaprobacion(models.Model):
    tipaprob = models.BigAutoField(db_column='TIPAPROB', primary_key=True)  # Field name made lowercase.
    tipaprobnombre = models.CharField(db_column='TIPAPROBNOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    tipaprobestado = models.IntegerField(db_column='TIPAPROBESTADO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPOAPROBACION'


class Tipodocumento(models.Model):
    tdocid = models.AutoField(db_column='TDOCID', primary_key=True)  # Field name made lowercase.
    tdocnombre = models.CharField(db_column='TDOCNOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    tdocjefatura = models.BigIntegerField(db_column='TDOCJEFATURA', blank=True, null=True)  # Field name made lowercase.
    tdocestado = models.IntegerField(db_column='TDOCESTADO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPODOCUMENTO'


class Tipoestadodocumento(models.Model):
    idtipestdoc = models.AutoField(db_column='IDTIPESTDOC', primary_key=True)  # Field name made lowercase.
    nombretipestdoc = models.CharField(db_column='NOMBRETIPESTDOC', max_length=350, blank=True, null=True)  # Field name made lowercase.
    estadotipestdoc = models.IntegerField(db_column='ESTADOTIPESTDOC', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPOESTADODOCUMENTO'


class Tiporeferencia(models.Model):
    tipreferenciaid = models.AutoField(db_column='TIPREFERENCIAID', primary_key=True)  # Field name made lowercase.
    tipreferencianombre = models.CharField(db_column='TIPREFERENCIANOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    tipreferenciaestado = models.IntegerField(db_column='TIPREFERENCIAESTADO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPOREFERENCIA'


class TipoAccionDocumento(models.Model):
    tip_acc_id = models.AutoField(db_column='TIP_ACC_ID', primary_key=True)  # Field name made lowercase.
    tip_acc_nombre = models.CharField(db_column='TIP_ACC_NOMBRE', max_length=350, blank=True, null=True)  # Field name made lowercase.
    tip_acc_estado = models.IntegerField(db_column='TIP_ACC_ESTADO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPO_ACCION_DOCUMENTO'


class TipoProceso(models.Model):
    id_tipo_proceso = models.BigAutoField(db_column='ID_TIPO_PROCESO', primary_key=True)  # Field name made lowercase.
    nombre_tipo_proceso = models.CharField(db_column='NOMBRE_TIPO_PROCESO', max_length=250, blank=True, null=True)  # Field name made lowercase.
    detalle_tipo_proceso = models.CharField(db_column='DETALLE_TIPO_PROCESO', max_length=350, blank=True, null=True)  # Field name made lowercase.
    estado_tipo_proceso = models.IntegerField(db_column='ESTADO_TIPO_PROCESO', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'TIPO_PROCESO'


class UbicacionArchivo(models.Model):
    idubicacion = models.BigAutoField(db_column='IDUBICACION', primary_key=True)  # Field name made lowercase.
    nombreubicacion = models.CharField(db_column='NOMBREUBICACION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    detalleubicacion = models.CharField(db_column='DETALLEUBICACION', max_length=500, blank=True, null=True)  # Field name made lowercase.
    fechaubicacion = models.DateTimeField(db_column='FECHAUBICACION', blank=True, null=True)  # Field name made lowercase.
    estadoubicacion = models.IntegerField(db_column='ESTADOUBICACION', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'UBICACION_ARCHIVO'


class Migrationhistory(models.Model):
    migrationid = models.CharField(db_column='MigrationId', primary_key=True, max_length=150)  # Field name made lowercase.
    contextkey = models.CharField(db_column='ContextKey', max_length=300)  # Field name made lowercase.
    model = models.BinaryField(db_column='Model')  # Field name made lowercase.
    productversion = models.CharField(db_column='ProductVersion', max_length=32)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = '__MigrationHistory'
        unique_together = (('migrationid', 'contextkey'),)


class Sysdiagrams(models.Model):
    name = models.CharField(max_length=128)
    principal_id = models.IntegerField()
    diagram_id = models.AutoField(primary_key=True)
    version = models.IntegerField(blank=True, null=True)
    definition = models.BinaryField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sysdiagrams'
        unique_together = (('principal_id', 'name'),)

from django.db import models

class VistaDocumentosPublicados(models.Model):
    documentonombre = models.CharField(max_length=350, primary_key=True)
    ultimaversion = models.IntegerField()
    documentodetalleid = models.TextField(blank=True, null=True)
    

    class Meta:
        managed = False
        db_table = 'VistaDocumentosPublicados'

