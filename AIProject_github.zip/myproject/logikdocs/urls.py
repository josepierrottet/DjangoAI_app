from django.urls import path
from . import views

urlpatterns = [
    path('vista_logikdocs/', views.vista_logikdocs, name='vista_logikdocs'),
]
