from django.apps import AppConfig


class LogikdocsConfig(AppConfig):
    name = 'logikdocs'
