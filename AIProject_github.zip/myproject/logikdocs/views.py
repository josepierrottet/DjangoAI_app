from django.shortcuts import render
from .logik_module import main, obtener_nombres_documentos

def vista_logikdocs(request):
    template="ai_app/documento_form.html"
    mensaje = ''
    resultado = ''
    nombres_documentos = obtener_nombres_documentos()

    if request.method == 'POST':
        nombre_documento = request.POST.get('nombre_documento')  # Asume que el nombre del documento se obtiene desde un input con nombre 'nombre_documento'
        requerimiento = request.POST.get('requerimiento')  # Asume que el requerimiento se obtiene desde un input con nombre 'requerimiento'
        resultado = main(requerimiento, nombre_documento)
        
        if resultado and resultado != "<Respuesta no encontrada aqui>":
            mensaje = 'Respuesta encontrada exitosamente.'
        else:
            mensaje = 'No se pudo encontrar la respuesta en el documento proporcionado.'
            
    return render(request, template, {
        'mensaje': mensaje, 
        'resultado': resultado,
        'nombres_documentos': nombres_documentos
    })
