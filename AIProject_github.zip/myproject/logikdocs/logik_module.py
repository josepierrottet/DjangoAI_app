from django.core.exceptions import ObjectDoesNotExist
import aspose.words as aw
from docx import Document
import tempfile
import os
from .models import VistaDocumentosPublicados
import openai
import datetime
import time

openai.api_key = "my_api_key"

def obtener_nombres_documentos():
    documentos = VistaDocumentosPublicados.objects.using("Base2").all()
    nombres = [doc.documentonombre for doc in documentos]
    return nombres


def obtener_detalle_documento(nombre):
    try:
        doc = VistaDocumentosPublicados.objects.using("Base2").get(documentonombre=nombre)
        return doc.documentodetalleid
    except ObjectDoesNotExist:
        return None


def archivo_texto_enriquecido(nombre):
    archivo1=obtener_detalle_documento(nombre)
    file_path = "textoenriquecido.txt"
    with open(file_path, "w", encoding="utf-8") as archivo:
            archivo.write(archivo1)
    return file_path



def convert_rtf_to_docx(rtf_path, docx_path):
    doc = aw.Document(rtf_path)
    doc.save(docx_path, aw.SaveFormat.DOCX)


def docx_to_text(docx_path):
    doc = Document(docx_path)
    full_text = [para.text for para in doc.paragraphs]
    return '\n'.join(full_text)


def write_to_temp_file(text, temp_txt_path):
    with open(temp_txt_path, "w", encoding="utf-8") as file:
        file.write(text)



def texot_sin_formato(nombre):
    # Create temporary files
    temp_docx = tempfile.NamedTemporaryFile(suffix=".docx", delete=False)
    temp_txt = tempfile.NamedTemporaryFile(suffix=".txt", delete=False)

    # Close the temporary files immediately after creation
    temp_docx.close()
    temp_txt.close()

    detalle_documento = archivo_texto_enriquecido(nombre) #devuelve un path
    # Convert RTF to DOCX
    convert_rtf_to_docx(detalle_documento, temp_docx.name)

    # Convert DOCX to plain text
    text = docx_to_text(temp_docx.name)

    # Write plain text to a temporary text file
    write_to_temp_file(text, temp_txt.name)

    # Delete temporary files
    os.unlink(temp_docx.name)
    os.unlink(temp_txt.name)

    return text  # You might want to return the final text



def leer_texto_en_chunks(texto, max_chars=1250):
    full_text = texto
    
    start = 0
    while start < len(full_text):
        end = start + max_chars
        if end < len(full_text):
            # Extender el chunk hasta el final de la oración más cercana
            while end < len(full_text) and full_text[end] != '.':
                end += 1
        chunk = full_text[start:end+1]  # Se suma 1 para incluir el punto final
        yield chunk
        start = end + 1  # Se suma 1 para no incluir el punto en el siguiente chunk


def chatgpt_response(messages):
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        temperature=0.7,
        top_p=0.1,

        frequency_penalty=1,
        messages=messages
    )
    return completion.choices[0].message["content"]


def main(requerimiento,nombre_documento):

    request_count = 0
    
    
    found_answer = False
    # Obtener la fecha y hora actual
    fecha_hora_actual = datetime.datetime.now()

    # Convertir la fecha y hora a una cadena
    fecha_hora_string = fecha_hora_actual.strftime("%Y-%m-%d %H:%M:%S")

    messages = [
    {"role": "system", "content":"Realiza todo lo que te pido de manera eficiente"},
    {"role": "system", "content":"La fecha y hora actual es: " + fecha_hora_string},
    {"role": "system", "content":"Tu rol es ayudarme a encontrar respuestas iterando a traves de varios textos , por favor escucha muy bien mis instrucciones"},
    {"role": "system", "content":"Si no encuentras una respuesta, siempre responde <Respuesta no encontrada>"},
    
    {"role": "user", "content": "Te voy a dar texto que es el resultado de chunks de un texto más grande"},
    {"role": "user", "content": "Debido al límite de tokens este texto tendrá un máximo de 1300 caracteres"},
    {"role": "user", "content": "Si no encuentras una respuesta exacta en estos 1300 caracteres entonces siempre responde <Respuesta no encontrada> para que podamos iterar en los siguientes 1300 caracteres"},
    {"role": "user", "content": "La pregunta o requerimiento que debes responder es la siguiente"},
    {"role": "user", "content": requerimiento},
    {"role": "user", "content": "Necesitas encontrar la respuesta a esa pregunta en los textos que te voy a ir proporcionando"},
    {"role": "user", "content": "Recuerda que si no encuentras la respuesta, siempre debes responder <Respuesta no encontrada> y ni un solo caracter extra"},
    {"role": "user", "content": "En caso de que encuentres DENTRO DE LOS TEXTOS una respuesta escribela de modo que responda la pregunta original de mejor manera y haz tu mejor esfuerzo por complementar esa respuesta con tus propios conocimientos si es posible"}
    ]

    textosinformato=texot_sin_formato(nombre_documento) #devuelve el texto sin formato del documento, es decir sin tablas ni imagenes
    generador =leer_texto_en_chunks(textosinformato) #divide el texto en partes más pequeñas

    for chunk in generador:
            
        messages_chunk = messages.copy()
        messages_chunk.append({"role": "user", "content": chunk})
        generated_text = chatgpt_response(messages_chunk)
            
        request_count += 1
        if request_count % 3 == 0:
            print("Esperando 1 minuto")
            time.sleep(61)

        if ("spuesta no encontrada" not in generated_text.strip()) and ("proporcionarme otro" not in generated_text.strip()) and ("no está presente" not in generated_text.strip()) and ("encuentra la respuesta" not in generated_text.strip()) and ("o siento" not in generated_text.strip() and ("o he encontrado una respuesta" not in generated_text.strip()) and ("requerimiento en este texto" not in generated_text.strip()) and ("No se ha encontrado") not in generated_text.strip() and ("o se especifica") not in generated_text.strip()):
            with open("Respuesta_de_la_ultima_preguntaSL.txt", "w", encoding="utf-8") as archivo:
                archivo.write(generated_text)
            print(generated_text)
            return generated_text

        if found_answer:
            break

    return "<Respuesta no encontrada aqui>"