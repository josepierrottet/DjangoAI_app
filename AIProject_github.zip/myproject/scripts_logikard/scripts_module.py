from __future__ import print_function

import os.path
import pyodbc
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import io
from googleapiclient.http import MediaIoBaseDownload
import time

# If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/drive.readonly']

def obtener_credenciales():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return creds



def descargar_archivo(service, file_id, full_file_path):  # Aquí cambio file_path a full_file_path
    request = service.files().get_media(fileId=file_id)
    fh = io.FileIO(full_file_path, 'wb')  # Aquí ya está definida full_file_path
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while done is False:
        status, done = downloader.next_chunk()
        print(f"Descargado {int(status.progress() * 100)}.")
    print("Descarga completa.")






def listar_archivos(service):
    resultados = service.files().list(
        pageSize=100,
        fields="nextPageToken, files(id, name)",
        q="mimeType='application/octet-stream' and name contains '.bak'"
    ).execute()

    items = resultados.get('files', [])

        

    return items



def restaurar_base_de_datos(nombre_de_la_base_de_datos, backup_file, server_name, user_name, password):
    # Crear una nueva conexión
    print("EMPEZO LA FUNCION")
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                          'SERVER=' + server_name + ';'
                          'DATABASE=master;'  # Conéctate a la base de datos master
                          'UID=' + user_name + ';'
                          'PWD=' + password, 
                          autocommit=True)  # Añade autocommit=True

    cursor = conn.cursor()

    # Obtener los nombres lógicos de los archivos MDF y LDF
    cursor.execute(f"RESTORE FILELISTONLY FROM DISK = '{backup_file}'")
    filelist = cursor.fetchall()
    logical_name_mdf = filelist[0][0]
    logical_name_ldf = filelist[1][0]

    # Crear la consulta SQL para restaurar la base de datos
    query = f'''
    RESTORE DATABASE {nombre_de_la_base_de_datos}
    FROM DISK = '{backup_file}'
    WITH MOVE '{logical_name_mdf}' TO 'C:\\respaldo_base\\{nombre_de_la_base_de_datos}.mdf',
    MOVE '{logical_name_ldf}' TO 'C:\\respaldo_base\\{nombre_de_la_base_de_datos}_log.ldf',
    REPLACE;
    '''
    print(query)

    # Ejecutar la consulta
    cursor.execute(query)

    time.sleep(10)
    print("consulta ejecutada")


    
    
    cursor.execute(f"USE {nombre_de_la_base_de_datos}")
    cursor.execute("SELECT * FROM INFORMATION_SCHEMA.TABLES")
    schemas = cursor.fetchall()


    time.sleep(5)
    # Cerrar la conexión

    cursor.execute("USE master")
    # Establecer la base de datos en modo de usuario único
    cursor.execute(f"ALTER DATABASE {nombre_de_la_base_de_datos} SET SINGLE_USER WITH ROLLBACK IMMEDIATE")
    # Borrar la base de datos
    cursor.execute(f"DROP DATABASE {nombre_de_la_base_de_datos}")


    #MENSAJE QUE ME AVISA QUE FUE VERIFICADA Y ELIMINADA
    
    mensaje_de_confirmacion="Se ha verificado y elimnado la base de datos"

    time.sleep(3)
    conn.close()

    return schemas, mensaje_de_confirmacion
    

    



def buscar_archivo_por_nombre(service, file_name):
    archivos = listar_archivos(service)
    for archivo in archivos:
        if archivo['id'] == file_name:
            print("Archivo encontrado")
            return archivo
    return None








# def main():
#     creds = obtener_credenciales()
#     service = build('drive', 'v3', credentials=creds)
#     archivos = listar_archivos(service)
#     file_path = r"C:\respaldo_base"  # Aquí defino file_path
#     for archivo in archivos:
#         file_id = archivo['id']
#         file_name = archivo['name']
#         full_file_path = os.path.join(file_path, file_name + '.bak')
#         descargar_archivo(service, file_id, full_file_path)
#         # Restaurar la base de datos después de descargar el archivo
#         restaurar_base_de_datos(file_name, full_file_path, 'nombre_del_servidor', 'nombre_de_usuario', 'contraseña')

