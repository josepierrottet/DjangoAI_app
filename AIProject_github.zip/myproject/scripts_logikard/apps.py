from django.apps import AppConfig


class ScriptsLogikardConfig(AppConfig):
    name = 'scripts_logikard'
