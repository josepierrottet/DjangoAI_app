from django.urls import path
from . import views

urlpatterns = [
    path('script_base/', views.listar_descargar_archivos, name='script_base'),
    path('lista_de_scripts/', views.lista_de_scripts, name='lista_de_scripts'),
]
