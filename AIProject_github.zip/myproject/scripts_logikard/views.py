from django.shortcuts import render
from .scripts_module import obtener_credenciales, build, listar_archivos, descargar_archivo, restaurar_base_de_datos, buscar_archivo_por_nombre
import os
def listar_descargar_archivos(request):
    creds = obtener_credenciales()
    service = build('drive', 'v3', credentials=creds)
    schema=""
    mensaje=""

    if request.method == 'POST':
        # Obtén el nombre del archivo seleccionado del formulario
        selected_file_id = request.POST.get('file_id')

        archivo = buscar_archivo_por_nombre(service, selected_file_id)
        if archivo:
            file_id = archivo['id']
            file_name_with_extension = archivo['name']
            file_name, _ = os.path.splitext(file_name_with_extension)
            file_path = os.path.join(r"C:\respaldo_base", file_name_with_extension + '.bak')
            descargar_archivo(service, file_id, file_path)
            print(file_name, file_path)
            schema,mensaje=restaurar_base_de_datos(file_name, file_path, "LKQLP42\SQLEXPRESS", "sa", "098422")
            print("RESPALDADO")

    archivos = listar_archivos(service)
    return render(request, 'ai_app/script_base.html', {'archivos': archivos,"schema":schema, "mensaje_comprobacion":mensaje})



def lista_de_scripts(request):
    return render(request, 'ai_app/lista_de_scripts.html')
